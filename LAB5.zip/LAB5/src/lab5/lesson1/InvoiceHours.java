/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5.lesson1;

import java.util.Date;

/**
 *
 * @author admin
 */
public class InvoiceHours extends Invoice {
    
    private int hoursRent;

    public InvoiceHours() {
    }

    public InvoiceHours(int hoursRent, String code, 
            String name, String roomCode, double unitPrice) {
        super(code, name, roomCode, unitPrice);
        this.hoursRent = hoursRent;
    }

    public int getHoursRent() {
        return hoursRent;
    }

    public void setHoursRent(int hoursRent) {
        this.hoursRent = hoursRent;
    }
    

    @Override
    public double getMoney() {
        if(24 < hoursRent || hoursRent < 30) {
            hoursRent = 24;
            return hoursRent * getUnitPrice();
        } else if (hoursRent > 30) {
            Math.ceil(hoursRent /= 24);
            return hoursRent * getUnitPrice();
        }
        return hoursRent * getUnitPrice();
    }
    
}
