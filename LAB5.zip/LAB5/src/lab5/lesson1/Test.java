/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5.lesson1;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Test {
    public static void main(String[] args) {
        ArrayList<Invoice> list = new ArrayList<>();
        InvoiceManagement i = new Management();
        while(true) {
            System.out.println("1. Input list ");
            System.out.println("2. Calcualate amount for each type ");
            int option = Common.InputInt("Enter option: ");
            switch(option) {
                case 1:
                    int size = Common.InputInt("Enter number of Invoice: ");
                    i.inputList(size);
                    break;
                case 2:
                    System.out.println("Money of each type: ");
                    i.calculateAmount();
                    break;
                
            }
        }
    }
}
