/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5.lesson1;

import java.util.Date;

/**
 *
 * @author admin
 */
public abstract class Invoice {
    private String  code;
    private String name;
    private String roomCode;
    private double unitPrice;

    public Invoice() {
    }

    public Invoice(String code, String name, String roomCode, double unitPrice) {
        this.code = code;
        this.name = name;
        this.roomCode = roomCode;
        this.unitPrice = unitPrice;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoomCode() {
        return roomCode;
    }

    public void setRoomCode(String roomCode) {
        this.roomCode = roomCode;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return code + "\t" + name + "\t" + roomCode + "\t" + unitPrice;
    }
    
    public abstract double getMoney();
        
}
