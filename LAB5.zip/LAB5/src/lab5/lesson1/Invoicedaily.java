/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5.lesson1;

import java.util.Date;

/**
 *
 * @author admin
 */
public class Invoicedaily extends Invoice {
    private int daysRent;

    public Invoicedaily() {
    }

    public Invoicedaily(int daysRent, String code, 
            String name, String roomCode, double unitPrice) {
        super(code, name, roomCode, unitPrice);
        this.daysRent = daysRent;
    }

    public int getDaysRent() {
        return daysRent;
    }

    public void setDaysRent(int daysRent) {
        this.daysRent = daysRent;
    }
    

    @Override
    public double getMoney() {       
        return (7 * daysRent) + (daysRent - 7) * getUnitPrice() * 0.8;
    }
    
}
