/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5.lesson1;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Management implements InvoiceManagement {
    Scanner input = new Scanner(System.in);

    ArrayList<Invoice> list;

    public Management(ArrayList<Invoice> list) {
        this.list = list;
    }

    public Management() {
    }

    public ArrayList<Invoice> getList() {
        return list;
    }

    public void setList(ArrayList<Invoice> list) {
        this.list = list;
    }

    @Override
    public void inputList(int size) {
        try {
            for (int i = 0; i < size; i++) {
                System.out.println("Enter customer name: ");
                String name = Common.input.readLine();
                System.out.println("Enter room code: ");
                String code = Common.input.readLine();
                System.out.println("Enter invoice code: ");
                String invoiceCode = Common.input.readLine();
                Double unitPrice = Common.InputDouble("Enter unit price: ");
                int state = Common.InputInt("Rent by hours '1' or daily '2'.");
                if (state == 1) {
                    System.out.println("Enter hours rent:");
                    int hoursRent = input.nextInt();
                    if (hoursRent <= 0) {
                        System.out.println("Enter again");
                    } else if (hoursRent < 24) {
                        break;
                    }
                    if (24 <= hoursRent && hoursRent <= 30) {
                        hoursRent = 24;
                    } else if (hoursRent > 30) {
                        Math.ceil(hoursRent / 24);
                    }
                    Invoice i1 = new InvoiceHours(hoursRent, code, name, invoiceCode, unitPrice);
                    list.add(i1);
                } else if (state == 2) {
                    int daysRent = Common.InputInt("Enter days rent: ");
                    Invoice i2 = new Invoicedaily(daysRent, code, name, invoiceCode, unitPrice);
                    list.add(i2);
                }
            }
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
    }

    @Override
    public void calculateAmount() {
        double amount1 = 0;
        double amount2 = 0;
        for (Invoice item : list) {
            if (item instanceof InvoiceHours) {
                amount1 += ((InvoiceHours) item).getHoursRent();
            }
        }
        for (Invoice item : list) {
            if (item instanceof Invoicedaily) {
                amount2 += ((Invoicedaily) item).getDaysRent();
            }
        }
        System.out.println("Money of hours rent: " + amount1);
        System.out.println("Money of daily rent: " + amount2);
    }

    @Override
    public void avgBillOctober2018() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
